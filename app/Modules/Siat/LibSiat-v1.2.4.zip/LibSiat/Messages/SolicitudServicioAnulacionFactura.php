<?php
namespace SinticBolivia\SBFramework\Modules\Invoices\Classes\Siat\Messages;

class SolicitudServicioAnulacionFactura extends SolicitudRecepcion
{
	public	$codigoMotivo;
	public	$cuf;
	
}
