<?php
namespace SinticBolivia\SBFramework\Modules\Invoices\Classes\Siat;

class SiatConfigCuis extends SiatConfigCode
{
}