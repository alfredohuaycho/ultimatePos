<?php
namespace App\Modules\Siat\Models;

use SinticBolivia\SBFramework\Modules\Invoices\Classes\Siat\DocumentTypes;
use SinticBolivia\SBFramework\Modules\Invoices\Classes\Siat\SiatConfig;
use SinticBolivia\SBFramework\Modules\Invoices\Classes\Siat\Services\ServicioSiat;
use SinticBolivia\SBFramework\Modules\Invoices\Classes\Siat\Services\ServicioFacturacion;
use Exception;
use SinticBolivia\SBFramework\Modules\Invoices\Classes\Siat\Services\ServicioFacturacionCodigos;
use App\Modules\Siat\Entities\Cufd;

class SiatModel 
{
	public function getConfig()
	{
		$config = new SiatConfig([
			'nombreSistema' => 'Terrapuertocb',
			'codigoSistema' => '7236AAC0462430AD49A61B6',
			'nit'           => 1023275028,
			'razonSocial'   => 'TERMINAL DE BUSES COCHABAMBA S.A.',
			'modalidad'     => ServicioSiat::MOD_ELECTRONICA_ENLINEA,
			'ambiente'      => ServicioSiat::AMBIENTE_PRUEBAS,
			'tokenDelegado'	=> 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJURVJCVVMxMiIsImNvZGlnb1Npc3RlbWEiOiI3MjM2QUFDMDQ2MjQzMEFENDlBNjFCNiIsIm5pdCI6Ikg0c0lBQUFBQUFBQUFETTBNREkyTWpjMU1MSUFBTEZwdG1nS0FBQUEiLCJpZCI6MTI1MDU2LCJleHAiOjE2OTU2MDAwMDAsImlhdCI6MTY2NDA4MDIyNCwibml0RGVsZWdhZG8iOjEwMjMyNzUwMjgsInN1YnNpc3RlbWEiOiJTRkUifQ.updk-225XlP8VLg2RcUplL4PVwpd6qxdXgiHG2Yt2quu_cRQQ-ed0jK2gUeHnPcsZ0SyU5A2xHqEjMCoz_sbQQ',
			'pubCert'		=> MOD_SIAT_DIR . SB_DS . 'certs' . SB_DS . 'terrapuerto' . SB_DS . 'TERMINAL_DE_BUSES_COCHABAMBA_SA_CER.pem',
			'privCert'		=> MOD_SIAT_DIR . SB_DS . 'certs' . SB_DS . 'terrapuerto' . SB_DS . 'ClavePrivada_JAIME_GONZALO_VEIZAGA_ZANABRIA.pem',
			'telefono'		=> '34345435',
			'ciudad'		=> 'COCHABAMBA GC'
		]);
		
		return $config;
	}
	public function getAvailableSectors()
	{
		$sectors = [
			'compraventa' 	=> ['label' => 'Compra Venta', 'code' => DocumentTypes::FACTURA_COMPRA_VENTA],
			'alquiler'		=> ['label' => 'Alquiler Inmuebles', 'code' => DocumentTypes::FACTURA_ALQUILER_INMUEBLES],
			'prevalorada'	=> ['label' => 'PreValorada', 'code' => DocumentTypes::FACTURA_PREVALORADA],
			
		];
		
		return $sectors;
	}
	public function getCuis(int $sucursal = 0, int $puntoVenta = 0, $renew = false)
	{
		$path = storage_path() . SB_DS . 'siat-data';
		if( !is_dir($path) )
			mkdir($path);
		
		$config = $this->getConfig();
		$filename = sprintf("%s/%d-%d-cuis.json", $path, $sucursal, $puntoVenta);
		
		$config->validate();
		//print_r($config);die;
		if( is_file($filename) && ($obj = json_decode(file_get_contents($filename))) && !$renew )
		{
			return $obj->RespuestaCuis;
		}
		
		$service = new ServicioFacturacionCodigos(null, null, $config->tokenDelegado);
		$service->setConfig((array)$config);
		$res = $service->cuis($puntoVenta, $sucursal);
		if( !isset($res->RespuestaCuis->codigo) )
		{
			$error = \sb_siat_get_messages($res->RespuestaCuis);
			throw new Exception(__('Unable to get cuis, invalid response. ' . implode('; ', $error)));
		}
		
		file_put_contents($filename, json_encode($res));
		
		return $res->RespuestaCuis;
	}
	public function getCufd(int $sucursal = 0, $puntoVenta = 0)
	{
		$config = $this->getConfig();
		$config->cuis = $this->getCuis($sucursal, $puntoventa)->codigo;
		$config->validate();
		//$cuis = $this->getCuis($config, $user, $sucursal, $puntoVenta);
		$service = new ServicioFacturacionCodigos($config->cuis->codigo, null, $config->tokenDelegado);
		$service->setConfig((array)$config);
		$res = $service->cufd($puntoVenta, $sucursal);
		//var_dump($config->cuis->codigo);print_r($res);die(__METHOD__);
		if( !isset($res->RespuestaCufd->codigo) )
			throw new Exception(__('Unable to get CUFD, invalid response. ' . \sb_siat_message($res->RespuestaCufd)));
		$cufd = new Cufd();	
		$cufd->codigo			= $res->RespuestaCufd->codigo;
		$cufd->codigo_control	= $res->RespuestaCufd->codigoControl;
		$cufd->direccion		= $res->RespuestaCufd->direccion;
		$cufd->codigo_sucursal	= $sucursal;
		$cufd->codigo_puntoventa	= $puntoVenta;
		$cufd->fecha_vigencia		= date('Y-m-d H:i:s', strtotime($res->RespuestaCufd->fechaVigencia));
		$cufd->save();
		
		return $cufd;
	}
	public function verificarNit($nit)
	{
		$config = $this->getConfig();
		$service = new ServicioFacturacionCodigos($config->cuis->codigo, null, $config->tokenDelegado);
		$service->setConfig((array)$config);
		$res = $service->verificarNit($nit);
		if( $res->RespuestaVerificarNit->mensajesList->codigo == 994 )
			throw new ExceptionInvalidNit("El NIT $nit no es valido", null, null);
			return true;
	}
}