<?php
namespace App\Modules\Siat\Models;

use App\Modules\Siat\Entities\Invoice;

class InvoiceModel extends SiatModel
{
	public function create(Invoice $invoice)
	{
		
	}
}