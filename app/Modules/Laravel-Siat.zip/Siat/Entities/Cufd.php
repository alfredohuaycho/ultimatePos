<?php
namespace App\Modules\Siat\Entities;

use Illuminate\Database\Eloquent\Model;

class Cufd extends Model
{
	protected	$table = 'mb_siat_cufd';
}