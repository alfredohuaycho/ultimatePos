<?php
namespace App\Modules\Siat\Entities;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
	protected	$table = 'mb_invoices';
	
	/**
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\HasMany
	 */
	public function items()
	{
		//return $this->morphMany(Comment::class, 'object', 'object_type');
		return $this->hasMany(InvoiceItem::class, 'invoice_id', 'id');
		//->orderBy('created_at', 'desc');
	}
}