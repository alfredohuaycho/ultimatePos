<?php
namespace App\Modules\Siat\Entities;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
	protected	$table = 'mb_siat_events';
}