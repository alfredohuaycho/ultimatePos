<?php
namespace App\Modules\Siat\Entities;

use Illuminate\Database\Eloquent\Model;

class InvoiceItem extends Model
{
	protected	$table = 'mb_invoice_items';
}