<?php
namespace App\Modules\Siat;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;
defined('SB_DS') or define('SB_DS', DIRECTORY_SEPARATOR);

class SiatProvider extends ServiceProvider
{
	protected	$namespace = 'App\Modules\Siat\Controllers';
	
	public function __construct($app)
	{
		parent::__construct($app);
	}
	public function register()
	{
		view()->addNamespace('Siat', __DIR__ . DIRECTORY_SEPARATOR . 'views');
	}
	public function boot()
	{
		date_default_timezone_set('America/La_Paz');
		$this->initLibSiat();
		$this->registerRoutes();
		$this->addListeners();
		$this->addFields();
	}
	protected function iniLibSiat()
	{
		require_once __DIR__ . SB_DS . 'LibSiat' . SB_DS . 'autoload.php';
	}
	protected function registerRoutes()
	{
		$web_routes = __DIR__ . DIRECTORY_SEPARATOR . 'routes' . DIRECTORY_SEPARATOR . 'web.php';
		$api_routes = __DIR__ . DIRECTORY_SEPARATOR . 'routes' . DIRECTORY_SEPARATOR . 'api.php';
		
		Route::middleware('web')
		->namespace($this->namespace)
		->group($web_routes);
		
		Route::prefix('api')
		->middleware('api')
		->namespace($this->namespace)
		->group($api_routes);
		
	}
	protected function addListeners()
	{
		
	}
	protected function addFields()
	{
		
	}
}