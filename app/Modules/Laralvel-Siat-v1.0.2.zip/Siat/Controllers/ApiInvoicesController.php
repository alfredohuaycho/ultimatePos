<?php
namespace App\Modules\Siat\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use App\Modules\Siat\Entities\Invoice;
use App\Modules\Siat\Models\InvoiceModel;
use App\Contact;
use Symfony\Component\HttpFoundation\ParameterBag;
use Illuminate\Support\Facades\Auth;
use App\Modules\Siat\Resources\ResourceInvoice;

class ApiInvoicesController extends Controller
{
	/**
	 * @var InvoiceModel
	 */
	protected	$invoicesModel;
	/*
	public function __construct(InvoiceModel $model)
	{
		$this->invoicesModel = $model;
	}
	*/
	public function create(InvoiceModel $model)
	{
		$user = auth()->user();
		try
		{
			$data = request()->json()->all();
			//print_r($data);die;
			$invoice = new Invoice();
			$invoice->fill($data);
			$invoice->codigo_puntoventa = $data['punto_venta'];
			
			if( $data['invoice_date_time'] )
				$invoice->invoice_datetime = $data['invoice_date_time'];
			//print_r($invoice);die;
			$invoice->saveItems($data['items']);
			//print_r($invoice->getSavedItems());die;
			$invoice->user_id = $user->id;
			if( !$invoice->invoice_datetime )
				$invoice->invoice_datetime = date('Y-m-d H:i:s');
			$model->create($invoice);
			return response(['data' => new ResourceInvoice($invoice)])->header('Content-Type', 'application/json');
		}
		catch(Exception $e)
		{
			return response(['error' => $e->getMessage()], 500)->header('Content-Type', 'application/json');	
		}
	}
	public function read()
	{
		
	}
	public function readAll()
	{
		$user = auth()->user();
		try
		{
			$limit	= 25;
			$page 	= (int)request()->get('page');
			$offset = ($page <= 1) ? 0 : (($page - 1) * $limit);
			$count	= Invoice::all()->count();
			$total_pages = ceil($count / $limit);
			$items 	= Invoice::orderBy('id', 'desc')->offset($offset)->limit($limit)->get();
			$invoices = [];
			foreach($items as $item)
			{
				$invoices[] = new ResourceInvoice($item);
			}
			return response(['data' => $invoices])
				->header('Content-Type', 'application/json')
				->header('Total-Pages', $total_pages);
		}
		catch(Exception $e)
		{
			return response(['error' => $e->getMessage()], 500)->header('Content-Type', 'application/json');
		}
	}
}