window.vueapp = '#siat-app';
SBFramework.Components.Siat = {};
Vue.use(SBFramework.Plugins.PluginToast, {});
Vue.use(SBFramework.Plugins.Processing, {});