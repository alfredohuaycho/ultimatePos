(function(ns)
{
	class ServiceCustomers extends SBFramework.Classes.Api
	{
		constructor()
		{
			super();
		}
		async create(customer)
		{
			const res = await this.Post(`/contacts`, customer);
			
			return res;
		}
		async read(id)
		{
			const res = await this.Get(`/invoices/customers/${id}`);
			
			return res;
		}
		async search(keyword)
		{
			const res = await this.Get(`/contacts/customers?q=${keyword}`, {'X-CSRF-TOKEN': document.head.querySelector('[name=csrf-token]').content});
			
			return {data: res};
		}
	}
	ns.ServiceCustomers = ServiceCustomers;
})(SBFramework.Services);