(function(ns)
{
	ns.ComTarjeta = {
		template: ``,
		mounted()
		{
			
		},
		created()
		{
			
		}
	};
})(SBFramework.Components.Siat);