<?php
namespace App\Modules\Siat\Classes;

class ExceptionInvalidNit extends ExceptionInvalidInvoiceData
{
	
}