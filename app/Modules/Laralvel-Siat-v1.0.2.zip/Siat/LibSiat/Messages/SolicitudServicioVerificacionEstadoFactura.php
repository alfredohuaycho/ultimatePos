<?php
namespace SinticBolivia\SBFramework\Modules\Invoices\Classes\Siat\Messages;

class SolicitudServicioVerificacionEstadoFactura extends SolicitudRecepcion
{
    /**
     * @var string
     */
    public  $cuf;
    
    public function __construct()
    {
        
    }
}